﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CollectibleController : MonoBehaviour
{
    public float min = 0.2f;
    public float max = 0.5f;
    
    void Start()
    {
        min = transform.position.y;
        max = transform.position.y + 0.1f;
        
    }

    void Update()
    {
        transform.position = new Vector3(transform.position.x, Mathf.PingPong(Time.time * 0.2f, max - min) + min, transform.position.z);
    }

   
}
