﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.SceneManagement;
using UnityEngine;
using UnityEngine.UI;





public class PlayerController : MonoBehaviour
{
    Animator myAnim;
    SpriteRenderer myRend;
    Rigidbody2D myBod;
    bool isGrounded;
    AudioSource myAudio;
    public AudioClip GameOver;
    public AudioClip pickup;





    public Transform ground; //boxcollider bottom
    public float groundCheckRadius;
    public LayerMask groundLayer;





    int life = 1;
    int score = 0;
    Text gameOver;
    Text scoreboard;





    void Start()
    {
        myAnim = GetComponent<Animator>();
        myRend = GetComponent<SpriteRenderer>();
        myBod = GetComponent<Rigidbody2D>();
        gameOver = GameObject.Find("GameOver").GetComponent<Text>();
        scoreboard = GameObject.Find("ScoreBoard").GetComponent<Text>();





        myAudio = GetComponent<AudioSource>();


        Time.timeScale = 1;


    }
    void Update()
    {
        isGrounded = Physics2D.OverlapCircle(ground.position, groundCheckRadius, groundLayer);
        float h = Input.GetAxis("Horizontal");
        Vector2 v = myBod.velocity;
        v.x = h * 5;
        myBod.velocity = v;





        myAnim.speed = 3;



        if (h > 0)
        {
            myRend.flipX = false;
            myAnim.SetBool("Ride", true);
        }
        else if (h < 0)
        {
            myRend.flipX = true;
            myAnim.SetBool("Ride", true);
        }
        else
        {
            myAnim.SetBool("Ride", false);
        }





        if (Input.GetButtonDown("Jump") && isGrounded)
        {
            myBod.velocity = new Vector3(6, 6, 0);
        }

        if (Input.GetButtonDown("Jump") && Time.timeScale <= 0)
        {
            SceneManager.LoadScene(0);
            Start();

        }

    }





    void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.tag == "Collectible" )
        {
            score += 1;
            scoreboard.text = "SCORE: " + score;
            myAudio.PlayOneShot(pickup);
            Destroy(collision.gameObject);
        }




        if (collision.gameObject.tag == "End")
        {
            gameOver.text = "U WIN JUSTICE! GOOD JOB";
            Invoke("StopGame", .25f);
        }
    }





    void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.tag == "Spikes" || collision.gameObject.tag == "Slime")
        {
            if (life > 0)
            {
                life--;
            }





            if (life == 0)
            {
                gameOver.text = "Jump to Try Again";
                myAnim.SetBool("Crash", true);
                Invoke("StopGame", .25f);
                myAudio.PlayOneShot(GameOver);

                

            }
        }
    }





    void StopGame()
    {
        Time.timeScale = 0;
    }





}