﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraController : MonoBehaviour
{
    Transform playerTransform;

    float y;
   
    void Start()
    {
        playerTransform = GameObject.Find("MumenRider").GetComponent<Transform>();
        y = transform.position.y;
    }

    void Update()
    {
        if (playerTransform.position.x < -73)
        {
            transform.position = new Vector3(-73, y, transform.position.z);
        }
        else
        {
            transform.position = new Vector3(transform.position.x, y, transform.position.z);
        }
        
    }
}
